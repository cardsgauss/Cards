package com.scb.gauss.dao.Impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.scb.gauss.bean.Appeal;
import com.scb.gauss.bean.Application;
import com.scb.gauss.dao.AppealDAO;
import com.scb.gauss.dao.Impl.ApplicationDAOImpl.ApplicationMapper;

@Repository
public class ApplealDAOimpl implements AppealDAO{

	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int add(Appeal a) {
		String query = "INSERT INTO appeal(cust_id,cust_name,status,reason) VALUES(?,?,?,?,?)";
		return jdbcTemplate.update(query, new Object[]{a.getCust_id(),
				 a.getCust_name(),a.getStatus(),a.getStatus(),a.getReason()});
	}
		

	@Override
	public List<Appeal> list() {
			String query = "SELECT * FROM appeal";
			return jdbcTemplate.query(query, new ApplicationMapper());
	}
		class ApplicationMapper implements RowMapper<Appeal> {

			
			public Appeal mapRow(ResultSet rs, int rowNum) throws SQLException {
				Appeal app = new Appeal();
				app.setCust_id(rs.getInt("cust_id"));
				app.setCust_name(rs.getString("cust_name"));
				app.setStatus(rs.getString("status"));
				app.setCredscore(rs.getInt("credit_score"));
				app.setReason(rs.getString("Reason"));
				return app;
			}

		}

}
