package com.scb.gauss.service;

import java.util.List;

import com.scb.gauss.bean.Appeal;


public interface AppealService {

	public int add(Appeal a);
	public List<Appeal> list();
}
