package com.scb.gauss.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.gauss.bean.Appeal;
import com.scb.gauss.dao.AppealDAO;
import com.scb.gauss.service.AppealService;

@Service
public class AppealServiceimpl implements AppealService {

	
	@Autowired
	private AppealDAO appDAO;
	
	@Override
	public int add(Appeal a) {
		return appDAO.add(a);

		
	}

	@Override
	public List<Appeal> list() {
		return appDAO.list();

	}

}
