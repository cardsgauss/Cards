package com.scb.gauss.dao;

import java.util.List;

import com.scb.gauss.bean.Appeal;
import com.scb.gauss.bean.Application;

public interface AppealDAO {
	public int add(Appeal a);
	public List<Appeal> list();

}
