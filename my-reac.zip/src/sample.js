<form className="leftContent">
                <div className="form-group">
                    <label for="ids">Id:</label>
                    <input type="number" className="form-control" id="ids" />
                </div>
                <div className="form-group">
                    <label for="fName">First Name:</label>
                    <input type="text" className="form-control" id="firstName" />
                </div>
                <div className="form-group">
                    <label for="lName">Last Name:</label>
                    <input type="text" className="form-control" id="lastName" />
                </div>
                <button type="button" onClick={(e) => this.onboard(e)} className="btn btn-default">Submit</button>
            </form>