import React from 'react';
import logo from './logo.svg';
import './App.css';
import CustomerForm from './CustomerForm';
import List from './list';
import Edit from './edit';
import {BrowserRouter as Router,Switch,Link,Route} from "react-router-dom";
import PostCustomer from './PostCustomer';
import AppForm from './appform';
import Table from './Table';
import Approval from './approval';
import CreditScore from './creditscore';
import AppealForm from './appealform';
import DocumentVerification from './document';
import Home from './Home';
import Appeal from './appeal';
import Login from './login';
/*function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}*/



class App extends React.Component {
 
  render(){
  return (
    <Router>
      
     
      
      <Switch>
       <Route  exact path="/" exact component={Login}/>
       <Route  exact path="/home" exact component={Home}/>
       <Route  exact path="/table" exact component={Table}/>
       <Route  exact path="/appealTable" exact component={Appeal}/>
        <Route  exact path="/edit" exact component={Edit}/>
        <Route path="/form" exact component={AppForm}/>
        <Route path="/credit" exact component={CreditScore}/>
        <Route path="/approval" exact component={Approval}/>
        <Route path="/appeal" exact component={AppealForm}/>
        <Route path="/document" exact component={DocumentVerification}/>
      </Switch>
      
    </Router>
  )
  }
}

export default App;
