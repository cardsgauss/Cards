import React from 'react';
import axios from 'axios';
import { Container } from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';

class AppForm extends React.Component {
    state = {
        customer: []
    }
    // constructor(props){
    //     super(props);
    //     this.state={
    //         fname:''
    //     };

    // }
    handleName = (e) => {
        /*
          Because we named the inputs to match their
          corresponding values in state, it's
          super easy to update the state
        */
        this.setState({ name: e.target.value });
    }
    handleEmail = (e) => {
        this.setState({ email: e.target.value });
    }
    handleMobile = (e) => {
        this.setState({ mobile: e.target.value });
    }
    handleProduct = (e) => {
        this.setState({ product: e.target.value });
    }
    handleAadhaar = (e) => {
        this.setState({ aadhaar: e.target.value });
    }
    handleAp = (e) => {
        this.setState({ address: e.target.value });
    }
    handleIncome = (e) => {
        this.setState({ income: e.target.value });
    }
    handleProfile = (e) => {
        this.setState({ profile: e.target.value });
    }
    onSubmit = (e) => {
        // const { fname } = this.state;
        this.newCustomer = {
            name: this.state.name,
            email: this.state.email,
            mobile: this.state.mobile,
            product: this.state.product,
            aadhaar: this.state.aadhaar,
            address: this.state.address,
            income: this.state.income,
            profile: this.state.profile
        }
        e.preventDefault();

        axios.post(`http://localhost:9000/customer/add`,             // email: document.getElementById('email').value,

            this.newCustomer
            //name: document.getElementById('name').value,
            //     mobile: document.getElementById('phone').value,
            //    product: document.getElementById('product').value,
            //     aadhaar: document.getElementById('aadhaar').value,
            //     address: document.getElementById('ap').value,
            //     income: document.getElementById('ip').value,
            //     profile: document.getElementById('sel2').value

        )
            .then(res => {

                if (res.data > 0) {
                    alert("Customer Created Successfully");
                    { this.setState({ [res.data]: this.customer }) };
                    let path = '/';
                    this.props.history.push(path);
                } else {
                    alert("Error creating Customer");
                }
            })

    }

    render() {
        const { fname } = this.state;
        //const {onSubmit} = this.props;
        return (
            <Paper style={{ marginLeft: "15%", marginRight: "15%", marginTop: "3%" }}>
                <Container maxWidth="xl" style={{ marginTop: "5%" }}>
                    <Grid>
                        <form onSubmit={this.onSubmit} >

                            <div className="row">

                                <div className="col-sm-12" >
                                    <h2 style={{ alignContent: 'center', textAlign: 'center', marginTop: "4%" }}>New User Application</h2>

                                    <br></br>
                                    <h5 className="text-center" style={{ fontWeight: '600' }} > Form Creation</h5>
                                    <br></br>



                                    <form className="form-horizontal" className="col-sm-12" style={{ paddingLeft: "25%" }}  >
                                        <div className="form-group">
                                            <label className="control-label col-sm-8" >Name:</label>
                                            <div className="col-sm-8">
                                                <input type="text" className="form-control" id="name" onChange={this.handleName} value={this.fname}
                                                    placeholder="Enter name"
                                                    required />
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <label className="control-label col-sm-8" >Email:</label>
                                            <div className="col-sm-8">
                                                <input type="email" className="form-control" id="email" placeholder="Enter email" name="email"
                                                    onChange={this.handleEmail} value={this.email} />
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <label className="control-label col-sm-8" >Mobile No:</label>
                                            <div className="col-sm-8">
                                                <input type="tel" className="form-control" id="phone" placeholder="Enter mobile no" name="phone"
                                                    onChange={this.handleMobile} value={this.mobile} />
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <label className="control-label col-sm-8" >Product:</label>
                                            <div className="col-sm-8">

                                                <select className="form-control" id="product" onChange={this.handleProduct} value={this.product}>
                                                <option>Please select Card Type</option>
                                                    <option>Silver</option>
                                                    <option>Gold</option>
                                                    <option>Platinum</option>

                                                </select>

                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <label className="control-label col-sm-8" >Aadhaar Card No:</label>
                                            <div className="col-sm-8">
                                                <input type="tel" className="form-control" id="aadhaar" onChange={this.handleAadhaar} value={this.aadhaar} placeholder="Enter aadhaar no" name="aadhaar"
                                                />
                                            </div>
                                            <div className="col-sm-8">
                                                <input type="file" id="ac" placeholder="Attachment" name="ac"
                                                />
                                            </div>

                                        </div>
                                        <div className="form-group">
                                            <label className="control-label col-sm-8" >Address proof:</label>
                                            <div className="col-sm-8">
                                                <input type="text" className="form-control" onChange={this.handleAp} value={this.ap} id="ap" placeholder="Enter Id proof no" name="ap"
                                                />
                                            </div>
                                            <div className="col-sm-8">
                                                <input type="file" id="address" name="address"
                                                />
                                            </div>



                                        </div>
                                        <div className="form-group">
                                            <label className="control-label col-sm-8" >Income proof:</label>
                                            <div className="col-sm-8">
                                                <input type="text" className="form-control" id="ip" placeholder="Enter pan card no" name="ip"
                                                    onChange={this.handleIncome} value={this.income} />
                                            </div>
                                            <div className="col-sm-8">
                                                <input type="file" id="pan" name="pan"
                                                />
                                            </div>

                                        </div>
                                        <div className="form-group">
                                            <label className="control-label col-sm-8" >Profile</label>
                                            <div className="col-sm-8">
                                                <div className="form-group">
                                                    <div className="col-sm-12">
                                                        <select className="form-control" onChange={this.handleProfile} value={this.profile} id="sel2">
                                                        <option>Please select Profile Type</option>
                                                            <option>New</option>
                                                            <option>Existing</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div>

                                        </div>



                                        <div className="but-al">

                                            <div className="form-group">
                                                <div className=" col-sm-8 col-sm-offset-6">
                                                    <button type="submit" className="btn btn-success"  >Submit</button>
                                                    

                                                    <button type="reset" className=" col-sm-offset-2" className="btn btn-default">Reset</button>
                                                </div>


                                            </div>
                                        </div>
                                    </form>

                                </div>

                            </div>

                        </form>
                    </Grid>

                </Container>
            </Paper>

        );
    }
}

export default AppForm;