import React, { Component } from 'react';
import './App.css';
import ReactTable from "react-table";
import "react-table/react-table.css";
class Test extends Component {
    constructor(props) {
        super(props);
        this.state = {
          posts: []
          
        }
    }
        componentDidMount() {
            const url = "http://localhost:9000/app";
            fetch(url, {
              method: "GET"
            }).then(reponse => reponse.json()).then(posts => {
              this.setState({ posts, posts })
            })
          }
        
    render() {
        const columns = [
            {
                header: "Customerid",
               // accessor:"id"
            },
            {
                header: "corporateName",
                  // accessor:"corporatename"
            },
            {
                header: "Email",
             //  accessor:"email"
            },

            {
                header: "Mobile",
                //   accessor:"mobile"
            }

        ]
    
    return(
    <div>
    <ReactTable>
        columns={columns}
        data={this.state.posts}
    </ReactTable>
                </div >
);
}
}
export default Test;





