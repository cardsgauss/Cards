import React from 'react';
import { Button, FormGroup, FormControl} from "react-bootstrap";
import axios from 'axios';
import Paper from '@material-ui/core/Paper'
import s from './sc.jpg';
import Grid from '@material-ui/core/Grid';
import { Container } from '@material-ui/core';
class Login extends React.Component{
    constructor(props) {
        super(props);
    
        this.state = {
           username:'',
           password: ''
         
        };
      }
    validateForm(e) {
        this.newLogin={
            username:this.state.username,
            password:this.state.password 
          }
            
           
            
             axios.post("http://localhost:9000/student/login",this.newLogin).then(
                
                 res=>{
                    //  this.setState({[res.data]:this.Login})
                    console.log(this.newLogin); 
                    console.log(res.data);   
                    if(res.data==1)
                    {
                    
          
                    let path='/home';
                     this.props.history.push(path);
                    alert("Logged In Successfully");
          
                  }
          
                  else
                  {
                      alert("error logging in");
                  }
                }) 
                }
       // return this.state.email.length > 0 && this.state.password.length > 0;
      
      handleName (event){
        this.setState({
          username: event.target.value
        });
        console.log(this.state.username);
      }
      handlePassword(event) {
        this.setState({
          password: event.target.value
        });
        console.log(this.state.password);
      }

      handleSubmit = event => {
        event.preventDefault();
      }
    
render() {
    return (
        <Grid container md={12}>
        <Grid iteam md={8}>
        <div style={{backgroundImage:"url("+ s +")",backgroundRepeat:'no-repeat',height:530 }} />
       </Grid>

       <Grid iteam md={4}>
       <Paper style={{marginTop:"25%", marginLeft:"5%",marginRight:"5%"}}>
       <Container maxWidth="md">
      <br></br>
      <div style={{textAlign:'center'}}>
      <h4>Log In</h4>
      </div>
      
      <div className="Login">
        <form onSubmit={this.handleSubmit}>
          <FormGroup controlId="email" bsSize="large">
            Username
            
            <FormControl
              autoFocus
              type="email"
              value={this.state.username}
              onChange={(e)=>this.handleName(e)}
            />
          </FormGroup>
          <FormGroup controlId="password" bsSize="large">
            Password
            <FormControl
              value={this.state.password}
              onChange={(e)=>this.handlePassword(e)}
              type="password"
            />
          </FormGroup>
          <Button
            block
            bsSize="large"
            onClick={()=>this.validateForm()}
            type="submit" 
          >
            Login
          </Button>
          <br></br>
          <br></br>
        </form>
      </div>
      </Container>
      </Paper>
      </Grid>
      </Grid>
  
    );
  }
}
export default Login;

