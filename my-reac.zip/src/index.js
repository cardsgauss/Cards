import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import CustomerForm from './CustomerForm';
import Ar from './ar';
import Appeal from './appeal';
import Document from './document';
import NextGen from './nextgen';
import Table from './Table';
//import  'bootstrap/dist/css/bootstrap.min.css';
import Edit from './edit';
import Navbar from './navbar';
//import Test from './test';
 ReactDOM.render(<App />, document.getElementById('root'));
 ReactDOM.render(<Navbar />, document.getElementById('root1'));
 //ReactDOM.render(<Appeal />, document.getElementById('root2'));
 //ReactDOM.render(<Edit />, document.getElementById('root2'));
//ReactDOM.render(<Test />, document.getElementById('root1'));
//ReactDOM.render(<NextGen />, document.getElementById('root2'));
//ReactDOM.render(<Table />, document.getElementById('root3'));
// ReactDOM.render(<CustomerForm />, document.getElementById('root1'));
// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
