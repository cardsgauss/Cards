import React from 'react';
import axios from 'axios';
class List extends React.Component{
    state={
        persons:[]
    }
    componentDidMount(){
        axios.get('http://localhost:9122/customer/').then(res=>
        {
            const persons=res.data;
            this.setState({persons});
        })
    }
    render(){
        return(
            <div>
<h6>Customer List</h6>
<ul>
    {this.state.persons.map(person=><li>{person.id} {person.name} {person.email} {person.mobile} {person.product} {person.aadhaar} {person.address} {person.income} {person.profile}</li>)}
</ul>

            </div>
        )
    }
}
export default List;