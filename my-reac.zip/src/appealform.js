
import React from 'react';
import axios from 'axios';
import { Paper, Container, Grid } from '@material-ui/core';

class AppealForm extends React.Component {
    state={
        customer:[]
    }
    // constructor(props){
    //     super(props);
    //     this.state={
    //         fname:''
    //     };
        
    // }
    handleName = (e) => {
        /*
          Because we named the inputs to match their
          corresponding values in state, it's
          super easy to update the state
        */
        this.setState({ name: e.target.value });
      }
      handleEmail = (e) => {
        this.setState({ email: e.target.value });
    }
    handleMobile = (e) => {
        this.setState({ mobile: e.target.value });
    }
    handleProduct = (e) => {
        this.setState({ product: e.target.value });
    }
    handleAadhaar = (e) => {
        this.setState({ aadhaar: e.target.value });
    }
    handleAp = (e) => {
        this.setState({ address: e.target.value });
    }
    handleIncome = (e) => {
        this.setState({ income: e.target.value });
    }
    handleProfile = (e) => {
        this.setState({ profile: e.target.value });
    }
      onSubmit = (e) => {
       // const { fname } = this.state;
this.newCustomer={  name:this.state.name,
                    email:this.state.email,
                    mobile:this.state.mobile,
                    product:this.state.product,
                    aadhaar:this.state.aadhaar,
                    address:this.state.address,
                    income:this.state.income,
                    profile:this.state.profile
}
        e.preventDefault();

        axios.post(`http://localhost:9000/customer/add`,             // email: document.getElementById('email').value,
            
          this.newCustomer
            //name: document.getElementById('name').value,
        //     mobile: document.getElementById('phone').value,
        //    product: document.getElementById('product').value,
        //     aadhaar: document.getElementById('aadhaar').value,
        //     address: document.getElementById('ap').value,
        //     income: document.getElementById('ip').value,
        //     profile: document.getElementById('sel2').value
            
        )
          .then(res => {
              
            if(res.data > 0) {
                alert("Customer Created Successfully");
                {this.setState({[res.data]:this.customer})};
               let path = '/';
    this.props.history.push(path);
            } else {
                alert("Error creating Customer");
            }
          })

    }
    createRow=()=>{
   
        let path = 'table';
        this.props.history.push(path);
        
    }

    render() {
        const { fname } = this.state;
         //const {onSubmit} = this.props;
        return (
            <Paper style={{marginLeft:"15%",marginRight:"15%",marginTop:"5%"}}>
            <Container maxWidth="xl" style={{marginTop:"5%"}}>
            <Grid>
        <form onSubmit={this.onSubmit}  >
        <div >
        
    
    <div >
        <br></br>
        <h1 style={{alignContent: 'center', textAlign: 'center'}}>Appeal Section</h1>
        
            
                <h5 className="text-center" style={{fontWeight:'600'}} > Appeal Form</h5>
            
            

                <form className="form-horizontal" style={{marginLeft:"35%", marginTop:"5%"}} >
                    <div className="form-group">
                        <label className="control-label col-sm-4" >CustID:</label>
                        <div className="col-md-6">
                            <input type="text" className="form-control" id="id" onChange={this.handleName} value={this.fname}
               
                               />
                        </div>
                    </div>
                    <div className="form-group">
                            <label className="control-label col-sm-4" >Cust Name</label>
                            <div className="col-md-6">
                                <input type="text" className="form-control" id="name"  name="name"
                                 onChange={this.handleEmail} value={this.email}   />
                            </div>
                        </div>
                        
                    
                    <div className="form-group">
                        <label className="control-label col-sm-4" >Credit Score:</label>
                        <div className="col-md-6">
                            <input type="text" className="form-control" id="creditscore" onChange={this.handleAadhaar} value={this.aadhaar}   name="creditscore"
                                />
                        </div>
                       
                       
                    </div>
                    <div className="form-group">
                        <label className="control-label col-sm-4" >Reason For Appeal:</label>
                        <div className="col-md-6">
                            <input type="text" className="form-control" onChange={this.handleAp} value={this.ap} id="reason" name="reason"
                                />
                            </div>
                            

                       
                       
                    </div>
                   
                  
                    

                   

                    <div className="but-al">

                        <div className="form-group">
                            <div className=" col-sm-8 col-sm-offset-6">
                                <button  type="button" className="btn btn-success" onClick={()=>{
                        this.createRow();}} >Submit</button>
                                
                                <button type="reset" className="btn btn-default">Reset</button>
                            </div>
                           
                                    
                        </div>
                        <br></br>
                        <br></br>
                    </div>
                </form>

            </div>
        </div>
    

</form>
</Grid>
</Container>
</Paper>
);
    }
}

export default AppealForm;

